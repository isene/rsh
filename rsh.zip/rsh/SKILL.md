---
name: rsh
description: Expert knowledge of the rsh (Ruby SHell) project - a feature-rich shell written in Ruby. Activate when working on rsh issues, debugging shell behavior, adding features, or releasing new versions. Covers architecture, configuration system, key functions, tab completion, nick/gnick aliases, autocorrect, and the release workflow. Project location is /home/geir/Main/G/GIT-isene/rsh.
---

# rsh - Ruby SHell

## Overview

rsh is a performance-critical interactive shell written in Ruby with extensive features including tab completion, aliases (nicks/gnicks), command history, syntax highlighting, theming, auto-cd, auto-opening files, autocorrect, and a plugin system.

**Performance requirements:**
- Target startup time: <500ms
- Tab completion must be instantaneous (<50ms)
- Never add file I/O, parsing, or spawns during startup without approval

## Project Structure

```
/home/geir/Main/G/GIT-isene/rsh/
├── bin/rsh              # Main executable (~4000+ lines)
├── rsh.gemspec          # Gem specification (version here!)
├── README.md            # Documentation
├── PLUGIN_GUIDE.md      # Plugin development guide
└── .rshrc               # Default config template
```

## Configuration System

rsh uses TWO configuration files with distinct purposes:

### ~/.rshrc (Portable, User-Editable)
Contains user preferences that should persist across machines:
- `@nick` - Command aliases (e.g., `{"ls" => "ls --color -F"}`)
- `@gnick` - Global text replacements (match anywhere, not just commands)
- `@bookmarks` - Directory bookmarks
- `@defuns` - User-defined functions
- `@prompt` - Prompt configuration
- `@auto_correct` - Enable/disable autocorrect
- Theme colors (`@c_prompt`, `@c_cmd`, etc.)

### ~/.rshstate (Auto-Managed, Machine-Specific)
Runtime state that changes frequently:
- `@history` - Command history
- `@cmd_frequency` - Usage statistics
- `@exe_cache` - Cached list of system executables
- `@completion_weights` - Tab completion learning data

## Key Functions (in bin/rsh)

### Nick System
- `def nick(nick_str)` - Define/list command nicks (`:nick ls = ls --color`)
- `def gnick(nick_str)` - Define/list global nicks (match anywhere)
- Nick substitution uses regex: `@cmd.gsub(Regexp.union(ca.keys), @nick)`

### Autocorrect System
- `def apply_auto_correct(cmd)` - Main autocorrect function
- `def suggest_command(cmd)` - Find similar commands using Levenshtein distance
- `def levenshtein_distance(s, t)` - String distance calculation
- Autocorrect triggers when: command not in @exe, @nick, or @defuns AND distance <= 2
- Paths (containing '/') are excluded from autocorrect

### Persistence
- `def rshrc` - Write portable config to ~/.rshrc (merges nicks from file first!)
- `def rshstate` - Write runtime state to ~/.rshstate
- `def persist_var(conf, var_name, value, condition)` - Helper to persist variables

### Exit Behavior
- **Ctrl-D**: Calls `rshrc` then exits (saves config)
- **Ctrl-C**: Exits immediately without saving

## Common Debugging Patterns

### "Command X gets changed to Y"
1. Check if it's autocorrect: Look for `apply_auto_correct` function
2. Check if it's a nick: Run `:nick` to list all nicks
3. Check if command is in @exe cache: Might not be recognized as valid

### "Nick/setting not persisting"
1. Check if `rshrc()` is being called after the change
2. Multiple instances issue: Old instances overwrite .rshrc on exit
3. v3.6.6+ merges nicks before writing to prevent loss

### "Tab completion issue"
1. Check `@exe_cache` in ~/.rshstate
2. Look at completion functions (search for `def.*complet`)
3. Check `@completion_weights` for learning data

## Release Workflow

When making changes to rsh:

```bash
# 1. Make code changes in bin/rsh

# 2. Test syntax
ruby -c bin/rsh

# 3. Update version in rsh.gemspec
# Edit s.version = 'X.Y.Z'

# 4. Commit and push
git add bin/rsh rsh.gemspec
git commit -m "Version X.Y.Z: Description"
git push

# 5. Build and release gem
gem build rsh.gemspec
gem push ruby-shell-X.Y.Z.gem

# 6. User can update with:
cp bin/rsh ~/bin/rsh  # Immediate
# or
gem install ruby-shell  # From RubyGems
```

## Timestamp Output Format

Commands are logged with timestamp before execution:
```ruby
puts "#{Time.now.strftime("%H:%M:%S")}: #{@cmd}".c(@c_stamp)
```
Output: `12:34:56: command_here`

When autocorrected (v3.6.4+):
```
12:34:56: corrected_cmd (autocorrected from "original")
```

## Important Code Locations

To find specific functionality, grep for:
- `def nick` - Nick management
- `def apply_auto_correct` - Autocorrect logic
- `def suggest_command` - Typo suggestions
- `def rshrc` - Config persistence
- `when 'C-D'` - Exit handling
- `@exe` / `@exe_cache` - Executable cache
- `Time.now.strftime` - Timestamp output locations
